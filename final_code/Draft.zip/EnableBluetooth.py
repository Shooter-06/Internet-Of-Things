import os
import time

while(True):
    os.system("bluetoothctl scan on")
    time.sleep(250)